package com.ifts4.tp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.navigation.findNavController
import com.ifts4.tp1.databinding.ActivityMainBinding
import com.ifts4.tp1.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private val viewmodel: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    override fun onBackPressed() {

        when(findNavController(R.id.fragmentContainerView).currentDestination!!.id){
            R.id.estudiantesListFragment->{

            }
            R.id.formularioFragment->{
                super.onBackPressed()
            }
        }

    }
}