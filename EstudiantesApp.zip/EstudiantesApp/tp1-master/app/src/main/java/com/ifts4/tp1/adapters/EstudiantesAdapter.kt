package com.ifts4.tp1.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.ifts4.tp1.R
import com.ifts4.tp1.config.Constantes
import com.ifts4.tp1.model.Estudiantes
import com.ifts4.tp1.ui.EstudiantesListFragmentDirections

// Esta clase es un adaptador para el RecyclerView y toma una lista de objetos Estudiantes como conjunto de datos.
class EstudiantesAdapter(private val dataSet: List<Estudiantes>) :
    RecyclerView.Adapter<EstudiantesAdapter.ViewHolder>() {

    // Este método se invoca cuando se necesita crear una nueva vista para un elemento de la lista.
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        // Crea una nueva vista inflando el archivo de diseño 'item_list.xml'.
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.item_list, viewGroup, false)

        return ViewHolder(view)
    }
    // Este método se invoca para enlazar los datos del conjunto de datos a una vista específica.
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val p = dataSet[position] //Obtiene el objeto Estudiantes correspondiente a la posición actual.
        viewHolder.bindItem(p) // Llama al método bindItem() en el ViewHolder para enlazar los datos del objeto Estudiantes a las vistas correspondientes.
    }
    // Devuelve el número total de elementos en el conjunto de datos.
    override fun getItemCount() = dataSet.size

    // Esta clase define el ViewHolder, que representa una única vista en el RecyclerView.
    class ViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val txtNombre: TextView
        val txtTelefono: TextView
        init { // El constructor init se llama al crear una nueva instancia de ViewHolder.
            txtNombre = view.findViewById(R.id.txt_nombre) // Busca y asigna la vista TextView correspondiente al ID 'txt_nombre'.
            txtTelefono = view.findViewById(R.id.txt_telefono) // Busca y asigna la vista TextView correspondiente al ID 'txt_telefono'.
        }

        // Este método se utiliza para enlazar los datos del objeto Estudiantes a las vistas correspondientes en el ViewHolder.
        fun bindItem(p: Estudiantes){
            txtNombre.text = p.nombre +" "+p.apellidos // Establece el texto del TextView txtNombre como el nombre y apellidos del estudiante concatenados.
            txtTelefono.text = p.telefono // Establece el texto del TextView txtTelefono como el número de teléfono del estudiante.
            val action = EstudiantesListFragmentDirections.actionEstudiantesListFragmentToFormularioFragment( // Crea una acción que representa la navegación desde el fragmento actual (EstudiantesListFragment) hacia el fragmento de formulario (FormularioFragment) con algunos datos extras.
                operacion =  Constantes.OPERACION_UPDATE,
                idEditar = p.idEstudiante,
                estudiantes = p
            )
            // Se configura un click listener en la vista actual, para que cuando se haga clic en ella, se navegue a la acción previamente definida.
            view.setOnClickListener {
                view.findNavController().navigate(action)
            }
        }
    }
}