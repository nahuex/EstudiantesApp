package com.ifts4.tp1.config

object Constantes { //Se  define un objeto singleton llamado "Constantes".
    const val OPERACION_INSERT = "NUEVO" //Se define una constante de cadena llamada OPERACION_INSERT y le asigna el valor "NUEVO". La palabra clave const indica que la constante es una variable en tiempo de compilación y su valor no puede cambiar una vez asignado.
    const val OPERACION_UPDATE = "EDITAR" //Se define otra constante de cadena llamada OPERACION_UPDATE y le asigna el valor "EDITAR". Al igual que la constante anterior, esta también es una variable en tiempo de compilación con un valor constante.
}