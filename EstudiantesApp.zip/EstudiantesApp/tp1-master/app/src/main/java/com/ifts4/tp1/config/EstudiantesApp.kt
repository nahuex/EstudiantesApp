package com.ifts4.tp1.config

import android.app.Application
import androidx.room.Room
import com.ifts4.tp1.db.EstudiantesDB

class EstudiantesApp: Application() { //Se define una clase llamada EstudiantesApp que hereda de la clase Application. Application es una clase base para mantener el estado global de la aplicación en Android.
    companion object{ //Se se declara un objeto companion que contiene una variable llamada db de tipo EstudiantesDB.
        lateinit var db:EstudiantesDB //El modificador lateinit se utiliza para indicar que la inicialización de esta variable se realizará en un momento posterior.
    }

// La función onCreate() que sobrescribe el método homónimo de la clase Application.
// Se ejecuta cuando la aplicación se inicia. Dentro de esta función, se llama al método databaseBuilder() de la clase Room para crear una instancia de la base de datos EstudiantesDB.
// Se utiliza el contexto actual (this), se especifica la clase EstudiantesDB como el tipo de base de datos y se proporciona el nombre de la base de datos como "Estudiantes".
// Luego, se invoca el método build() para construir la base de datos y se asigna a la variable db previamente declarada.

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(
            this,
            EstudiantesDB::class.java,
            "Estudiantes"
        ).build()
    }
}