package com.ifts4.tp1.dao

import androidx.room.*
import com.ifts4.tp1.model.Estudiantes

@Dao //@Dao es una anotación utilizada por la biblioteca Room en Android para identificar interfaces que actúan como DAO (Objetos de Acceso a Datos). Los DAO son componentes que definen los métodos de acceso a la base de datos.
interface EstudiantesDao {
    @Query("SELECT * FROM Estudiantes")
    suspend fun getAll():List<Estudiantes> //Se define un método llamado getAll() que devuelve una lista de objetos Estudiantes, que representa todos los registros de la tabla "Estudiantes".

    @Insert
    suspend fun insert(estudiante:Estudiantes):Long //Se define un método llamado insert() que toma un objeto Estudiantes como argumento y devuelve un valor de tipo Long, que generalmente representa el ID del registro insertado.

    @Update
    suspend fun update(estudiante:Estudiantes):Int //Se define un método llamado update() que toma un objeto Estudiantes como argumento y devuelve un valor de tipo Int, que representa el número de filas afectadas por la operación de actualización.

    @Delete
    suspend fun delete(estudiante: Estudiantes):Int //Se define un método llamado delete() que toma un objeto Estudiantes como argumento y devuelve un valor de tipo Int, que representa el número de filas afectadas por la operación de eliminación.

    @Query("SELECT * FROM Estudiantes WHERE nombre LIKE '%' || :name || '%' OR apellidos LIKE '%' || :name || '%'")
    suspend fun getByName(name: String): List<Estudiantes> //Se define un método llamado getByName() que toma un argumento de tipo String llamado name y devuelve una lista de objetos Estudiantes que cumplen con los criterios de búsqueda.
}