package com.ifts4.tp1.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.ifts4.tp1.dao.EstudiantesDao
import com.ifts4.tp1.model.Estudiantes

@Database( //@Database es una anotación utilizada en la biblioteca de Room para indicar que esta clase es una base de datos.
    entities = [Estudiantes::class], //Entities se establece como un array que contiene la clase Estudiantes, lo que significa que Estudiantes es una entidad de la base de datos.
    version = 1 //Version se establece en 1, lo que indica la versión de la base de datos.
)
abstract class EstudiantesDB: RoomDatabase() { //Se  declara una clase llamada EstudiantesDB que es una subclase de RoomDatabase. La palabra clave abstract indica que esta clase es abstracta y no se puede instanciar directamente.
    abstract fun estudiantesDao():EstudiantesDao //Se declara una función abstracta llamada estudiantesDao(), que es un método para acceder al objeto EstudiantesDao.
}