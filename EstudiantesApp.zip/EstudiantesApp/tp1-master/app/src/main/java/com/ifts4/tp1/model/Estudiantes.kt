package com.ifts4.tp1.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable


@Entity //La anotación @Entity se utiliza en el framework de Room para indicar que esta clase es una entidad de base de datos.
data class Estudiantes( //Se declara la clase Estudiantes. Es una clase de datos (data class) en Kotlin, lo que significa que se generan automáticamente los métodos equals(), hashCode(), toString(), etc.
    @PrimaryKey(autoGenerate = true) //La anotación @PrimaryKey indica que es la clave primaria, y autoGenerate = true especifica que se generará automáticamente un valor único para esta propiedad.
    @ColumnInfo(name="id_estudiante")   var idEstudiante:Long = 0, //Se define la propiedad idEstudiante como la clave primaria de la entidad.
    @ColumnInfo(name="nombre")          var nombre:String = "", //Se define la propiedad nombre de tipo String.
    @ColumnInfo(name="apellidos")       var apellidos:String = "", //Se define la propiedad apellidos de tipo String.
    @ColumnInfo(name="telefono")        var telefono:String = "", //Se define la propiedad telefono de tipo String.
    @ColumnInfo(name="edad")            var edad:Int = 0 //Se define la propiedad edad de tipo Int.
): Serializable //La clase Estudiantes implementa la interfaz Serializable.