package com.ifts4.tp1.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.ifts4.tp1.R
import com.ifts4.tp1.adapters.EstudiantesAdapter
import com.ifts4.tp1.config.Constantes.OPERACION_INSERT
import com.ifts4.tp1.databinding.FragmentEstudiantesListBinding
import com.ifts4.tp1.viewmodel.MainViewModel


class EstudiantesListFragment : Fragment() {
    private val model: MainViewModel by activityViewModels() // Creación de una instancia del ViewModel compartida por la actividad
    private var _binding: FragmentEstudiantesListBinding? = null // Variable para almacenar la referencia al binding del fragmento
    private val binding get() = _binding!! // Propiedad para acceder al binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentEstudiantesListBinding.inflate(inflater,container,false)  // Inflar el layout del fragmento y asignarlo al binding
        val view = binding.root // Obtener la vista raíz del layout del fragmento
        return view // Devolver la vista raíz
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.modelo = model // Asignar el ViewModel al binding
        binding.lifecycleOwner = viewLifecycleOwner // Establecer el lifecycleOwner del binding
        model.iniciar() // Llamar al método iniciar() del ViewModel
        binding.miRecycler.layoutManager = LinearLayoutManager(requireContext()) // Establecer el LinearLayoutManager para el RecyclerView
        model.estudiantesList.observe(viewLifecycleOwner, Observer { // Observar los cambios en la lista de estudiantes del ViewModel
            binding.miRecycler.adapter = EstudiantesAdapter(it!!) // Asignar el adaptador EstudiantesAdapter a RecyclerView con la lista de estudiantes actualizada
        })

        binding.btnNuevo.setOnClickListener { // Configurar un click listener para el botón btnNuevo
            val action = EstudiantesListFragmentDirections.actionEstudiantesListFragmentToFormularioFragment(operacion = OPERACION_INSERT)
            findNavController().navigate(action) // Navegar al fragmento FormularioFragment con la operación de inserción
        }

        model.parametroBusqueda.observe(viewLifecycleOwner, Observer {
            model.buscarEstudiante() // Observar los cambios en el parámetro de búsqueda y llamar al método buscarEstudiante() del ViewModel
        })


    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null // Liberar la referencia al binding en el momento de destruir el fragmento
    }
}