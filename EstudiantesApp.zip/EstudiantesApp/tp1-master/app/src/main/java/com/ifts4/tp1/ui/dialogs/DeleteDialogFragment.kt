package com.ifts4.tp1.ui.dialogs

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.ifts4.tp1.R

// Se define una clase llamada DeleteDialogFragment que hereda de DialogFragment. Además, se declara un constructor primario que recibe un parámetro listener del tipo DeleteListener.
class DeleteDialogFragment(val listener:DeleteListener): DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            // Use the Builder class for convenient dialog construction
            val builder = AlertDialog.Builder(it)
            builder.setMessage(R.string.confirm_delete)
                .setPositiveButton(R.string.yes,
                    DialogInterface.OnClickListener { dialog, id ->
                        listener.borrarEstudiante()
                    })
                .setNegativeButton(R.string.cancel,
                    DialogInterface.OnClickListener { dialog, id ->
                        dialog.cancel()
                    })
            // Create the AlertDialog object and return it
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    //Se define una interfaz llamada DeleteListener que declara un método borrarEstudiante(). Esta interfaz se utiliza para comunicar eventos de borrado desde el diálogo a la clase que implementa la interfaz.
    interface DeleteListener{
        fun borrarEstudiante()
    }
}