package com.ifts4.tp1.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ifts4.tp1.config.Constantes
import com.ifts4.tp1.config.EstudiantesApp.Companion.db
import com.ifts4.tp1.model.Estudiantes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel: ViewModel() {
    private val _estudiantesList = MutableLiveData<List<Estudiantes>?>()
    val estudiantesList : LiveData<List<Estudiantes>?> get() = _estudiantesList

    //-1 estado inicial, 0 -> error, 1->Exito
    private val _operacionExitosa = MutableLiveData<Int>()
    val operacionExitosa: LiveData<Int> get() = _operacionExitosa
    var operacion = Constantes.OPERACION_INSERT

    var idEstudiante = MutableLiveData<Long>()
    val nombre = MutableLiveData<String>()
    val apellido = MutableLiveData<String>()
    val telefono = MutableLiveData<String>()
    val edad = MutableLiveData<Int>()
    val parametroBusqueda = MutableLiveData<String>()


    init {
        //edad.value = 18
    }

    fun iniciar(){
        _operacionExitosa.value = -1
        limpiarDatos()
        viewModelScope.launch {
            _estudiantesList.value = withContext(Dispatchers.IO){
                db.estudiantesDao().getAll()
            }
        }
    }

    fun guardarEstudiante(){
        var mEstudiantes = Estudiantes(0,nombre.value!!,apellido.value!!,telefono.value!!,edad.value!!)
        when(operacion){
            Constantes.OPERACION_INSERT->{
                viewModelScope.launch {
                    val result = withContext(Dispatchers.IO){
                        db.estudiantesDao().insert(mEstudiantes)
                    }

                    if(result>0){
                        _operacionExitosa.value = 1
                    }
                    else{
                        _operacionExitosa.value = 0
                    }
                }
            }
            Constantes.OPERACION_UPDATE->{
                mEstudiantes.idEstudiante = idEstudiante.value!!
                viewModelScope.launch {
                    val result = withContext(Dispatchers.IO){
                        db.estudiantesDao().update(mEstudiantes)
                    }

                    if(result>0){
                        _operacionExitosa.value = 1
                    }
                    else{
                        _operacionExitosa.value = 0
                    }
                }
            }
        }
    }

    fun limpiarDatos(){
        nombre.value = ""
        apellido.value = ""
        telefono.value = ""
        edad.value = 18
    }

    fun borrarEstudiante() {
        var mEstudiantes = Estudiantes(idEstudiante.value!!)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO){
                db.estudiantesDao().delete(mEstudiantes)
            }
            if(result>0){
                _operacionExitosa.value = 1
            }
            else{
                _operacionExitosa.value = 0
            }
        }
    }

    fun buscarEstudiante(){
        viewModelScope.launch {
            _estudiantesList.value = withContext(Dispatchers.IO){
                if(parametroBusqueda.value?.trim().isNullOrEmpty()){
                    db.estudiantesDao().getAll()
                }else{
                    db.estudiantesDao().getByName(parametroBusqueda.value!!)
                }
            }
        }
    }
}